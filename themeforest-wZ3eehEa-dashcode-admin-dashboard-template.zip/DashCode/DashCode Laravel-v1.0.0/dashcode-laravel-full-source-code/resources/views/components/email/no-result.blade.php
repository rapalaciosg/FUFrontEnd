<li class="mx-6 mt-6 " id="no-result">
    <span class="badge bg-danger-500 text-white w-full block text-start">
        <span class="inline-flex items-center">No Result Found</span>
    </span>
</li>